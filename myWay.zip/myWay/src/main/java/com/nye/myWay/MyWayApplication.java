package com.nye.myWay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyWayApplication.class, args);
	}

}
